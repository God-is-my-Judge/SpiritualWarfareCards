# Spiritual Warfare: The Card Game -- Nova Bíblia Viva (Biblica® Open, 2007)

Scripture cards, Day and Night decks, 42 cards each. Portuguese scenarios: 12 cards per Day/Night deck.

## Scripture text

Nova Biblia Viva (Biblica(R) Open).
Copyright (c) 2007, 2010 Biblica, Inc.
Licensed under Creative Commons Attribution-ShareAlike 4.0 International (CC BY-SA 4.0).

## The cards

Game instructions and scenario material are licensed CC BY 4.0:
"Based on Spiritual Warfare: The Card Game by Daniel W Kerr, licensed under
CC BY 4.0. Changes were made. spiritualwarfarecards.com"

Because the Scripture text is ShareAlike, the Scripture cards in
this folder are distributed under CC BY-SA 4.0 as well.

Cards quote the translation above verbatim. Where a card skips
verses the omission is marked with an ellipsis; a smaller mark is an omission
inside one chapter, a larger one across chapters or books.

## Status

These decks carry Scripture cards and Portuguese scenario cards. Each Scripture card opens with a headline
pull-quote, which is not written but taken verbatim from the underlined
phrases of that card's own body -- so every word of it is this
translation's own. Which phrases to pull is an editorial choice that has
not yet been reviewed by a reader of this language. The passages have not
been shortened for length the way the English deck's are.
Portuguese Day and Night scenarios are included, 12 cards each.
The scenarios translate original game prose, not Bible verses;
they are CC BY 4.0, separately from the Scripture text's licence.
They have had an editorial comparison with the English source;
native-speaker feedback is welcome. Instructions remain in English.

Free to download, print and play for personal and ministry use.
spiritualwarfarecards.com
