# Spiritual Warfare: The Card Game -- Neno: Bibilia Takatifu (Biblica® Toleo Wazi)

## Quick start offline

Unzip the entire folder, keeping its files together. Open `DeckShuffle_sw.html` in your browser. The table deals one Day scenario, four Day Scripture cards, one Night scenario, and four Night Scripture cards in that order. Click a card to enlarge it. This edition uses English scenario cards.

Page 1 of each PDF contains copyright and license information. DeckShuffle skips that page automatically.

Scripture cards, Day and Night decks, 42 cards each.

## Scripture text

Neno: Bibilia Takatifu (Biblica(R) Toleo Wazi), the Open Kiswahili
Contemporary Version.
Copyright (c) 1984, 1989, 2009, 2015 Biblica, Inc.
Licensed under Creative Commons Attribution-ShareAlike 4.0 International (CC BY-SA 4.0).

## The cards

Game instructions and scenario material are licensed CC BY 4.0:
"Based on Spiritual Warfare: The Card Game by Daniel W Kerr, licensed under
CC BY 4.0. Changes were made. spiritualwarfarecards.com"

Because the Scripture text is ShareAlike, the Scripture cards in
this folder are distributed under CC BY-SA 4.0 as well.

Cards quote the translation above verbatim. Where a card skips
verses the omission is marked with an ellipsis; a smaller mark is an omission
inside one chapter, a larger one across chapters or books.

## Status

These decks carry the Scripture cards only. Each card opens with a headline
pull-quote, which is not written but taken verbatim from the underlined
phrases of that card's own body -- so every word of it is this
translation's own. Which phrases to pull is an editorial choice that has
not yet been reviewed by a reader of this language. The passages have not
been shortened for length the way the English deck's are.
Scenario cards and instructions are not yet translated.

Free to download, print and play for personal and ministry use.
spiritualwarfarecards.com
