# Spiritual Warfare: The Card Game -- Unrevised Elberfelder Bible (1905)

Scripture cards, Day and Night decks, 42 cards each.

## Scripture text

Elberfelder Bibel 1905 (unrevidiert). Public domain / gemeinfrei.
No licence conditions apply to the Scripture text.

## The cards

Game instructions and scenario material are licensed CC BY 4.0:
"Based on Spiritual Warfare: The Card Game by Daniel W Kerr, licensed under
CC BY 4.0. Changes were made. spiritualwarfarecards.com"

Cards quote the translation above verbatim. Where a card skips
verses the omission is marked with an ellipsis; a smaller mark is an omission
inside one chapter, a larger one across chapters or books.

## Status

These decks carry the Scripture cards only. The headline pull-quote above
each card's rule has not yet been chosen, and the passages have not been
shortened for length the way the English deck's are -- both need a reader
of this language.
Scenario cards and instructions are not yet translated.

Free to download, print and play for personal and ministry use.
spiritualwarfarecards.com
