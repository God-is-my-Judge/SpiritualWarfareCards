# Spiritual Warfare: The Card Game -- Tamil Indian Revised Version

## Quick start offline

Unzip the entire folder, keeping its files together. Open `DeckShuffle_ta.html` in your browser. The table deals one Day scenario, four Day Scripture cards, one Night scenario, and four Night Scripture cards in that order. Click a card to enlarge it.

Page 1 of each PDF contains copyright and license information. DeckShuffle skips that page automatically.

Scripture cards, Day and Night decks, 42 cards each. Tamil scenarios: 12 cards per Day/Night deck.

## Scripture text

Indian Revised Version.
Copyright (c) 2017-2021 Bridge Connectivity Solutions Pvt. Ltd.
Licensed under Creative Commons Attribution-ShareAlike 4.0 International (CC BY-SA 4.0).

## The cards

Game instructions and scenario material are licensed CC BY 4.0:
"Based on Spiritual Warfare: The Card Game by Daniel W Kerr, licensed under
CC BY 4.0. Changes were made. spiritualwarfarecards.com"

Because the Scripture text is ShareAlike, the Scripture cards in
this folder are distributed under CC BY-SA 4.0 as well.

Cards quote the translation above verbatim. Where a card skips
verses the omission is marked with an ellipsis; a smaller mark is an omission
inside one chapter, a larger one across chapters or books.

## Status

These decks carry Scripture cards and Tamil scenario cards. Each Scripture card opens with a headline
pull-quote, which is not written but taken verbatim from the underlined
phrases of that card's own body -- so every word of it is this
translation's own. Which phrases to pull is an editorial choice that has
not yet been reviewed by a reader of this language. The passages have not
been shortened for length the way the English deck's are.
Tamil Day and Night scenarios are included, 12 cards each.
The scenarios translate original game prose, not Bible verses;
they are CC BY 4.0, separately from the Scripture text's licence.
They have had an editorial comparison with the English source;
native-speaker feedback is welcome. Instructions remain in English.

Free to download, print and play for personal and ministry use.
spiritualwarfarecards.com

The owner authorized release on 23 October 2026.
Fluent-reader review of the scenario translation remains outstanding.
