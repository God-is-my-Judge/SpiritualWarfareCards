# A Praying Story

A small prayer-card desk for persons, households, church and ministry, the heart, suffering, mission, unfolding stories, and thanksgiving. Its original prompts are inspired by Paul Miller’s practice of keeping prayer requests, Scripture, and dated story notes together. The categories and artwork are original; this is not an official seeJesus app.

## Start

Open **Prayer-Desk.html** in a browser that can run local HTML, or use the hosted app. No installation, account, remote Bible service, or dependency is required for the downloaded app.

- Open **My-Prayer-Cards.md**, or start with eight editable templates.
- Switch the atmosphere from the menu: Simple Bible, Victorian Reverie, Deep Space, Jungle Adventure, Stained Glass, Celestial Chronicle, Storm & Glory, Woodland Chronicle, Desert Manuscript, Watercolor Creation, Summit & Sky, Galilee Spring, or Ohana Sunset.
- Tap a card to enlarge it. Tap its content to edit. Tap its outer border or the area outside it to close. Use the previous/next controls to pray through your deck.
- Bold and italic text use Markdown. Underline uses `<u>words</u>`. The formatting buttons wrap selected text in the active text field.
- Each card can override the desk’s theme, choose an illustration, and set a tint. The tint affects card backgrounds only. Text and border colors stay fixed for readability in each theme.
- Add dated notes to watch the story unfold. “God’s Story” includes waiting and partial change, not only completed answers.

The thirteen atmospheres and Mixed atmospheres option offer different moods rather than assigning styles by age or gender. Summit & Sky has clear lettering and restrained mountain scenery; Galilee Spring has bright wildflowers and a lakeside meadow. Simple Bible uses cool paper and minimal decoration. For larger type, enable Larger reading text in Settings. Scenery is still and never flashes.

Artwork forms a border around the requests. The main prayers have a protected reading surface; Story and Scripture use a more transparent lower surface. Storm & Glory has subtle storm clouds and an open Bible. Stained Glass offers Christ as the Good Shepherd with sheep and cup-and-bread iconography. Simple Bible uses cool white backgrounds with three sparse pen-art choices: outlined crosses, restrained Celtic crosses, and fine corner flourishes. Earlier Simple Bible art names now resolve to these new white pen designs. Woodland uses the border by default; choose the Wonder art variant for the realistic forest. The menu includes the relaxed Ohana Sunset.

**Personal photo:** open a card’s editor, optionally enter a filename or path label, then choose a JPEG, PNG, or WebP image (up to 12 MB). The card’s `photo="Pictures/sunset.jpg"` metadata remains human-readable. A name or path label never causes a network request or automatic filesystem access. Browsers require explicit file selection; choose the matching image to associate it with the label. The image is remembered only in this browser’s local IndexedDB, with a session-only fallback if storage fails. The app tells you when a photo could not be remembered. Photos are not embedded in Markdown or sent to a server. Keep your originals and choose them again on another device, after clearing site data, or in a browser that cannot persist local-file storage. Use theme artwork to remove a card’s photo override, or Settings → Forget remembered photos to erase the browser’s photo copies while preserving original pictures and Markdown labels.

## Mixed atmospheres and appearance links

Mixed atmospheres gives each card a varied atmosphere and illustration on a neutral page. A small `visual-id` per card and a desk `mix-seed` keep the selection stable while the title, prayer text, or kind is edited. Card theme overrides still take priority. Built-in artwork and appearance data stay local with the file.

Copy appearance link copies a hosted link containing appearance settings only. It contains no prayer text, dates, card titles, local-photo paths, or images. The hosted app's existing sharing permissions still apply; copying a link does not grant access. Query settings take precedence over saved presentation preferences when the page opens. Card kind and cadence are defaults for newly added cards and do not reclassify an existing prayer deck.

| URL parameter | Options |
|---|---|
| `theme` (or `atmosphere`) | `quiet`, `mixed`, `victorian`, `space`, `jungle`, `traditional`, `celestial`, `storm`, `woodland`, `desert`, `summit`, `galilee`, `watercolor`, `ohana` |
| `art` (or `variant`) | `auto` or a named built-in variant; explicit card choices take priority |
| `tint` | A named tint or encoded six-digit hex, e.g. `%23537cac` |
| `kind` | `person`, `family`, `church`, `heart`, `suffering`, `mission`, `story`, `thanks`; new-card default |
| `cadence` | `daily`, `weekly`, `sometimes`; new-card default |
| `card-theme` | `inherit` or any theme key; new-card default |
| `scripture`, `large` | `on`/`off`, `true`/`false`, or `1`/`0` |
| `seed` | Short alphanumeric/hyphen seed for Mixed atmospheres |

Examples: `?theme=woodland&art=wonder`, `?theme=quiet`, `?theme=mixed`, or `?theme=space&art=depth&large=on&kind=church&cadence=weekly`. Invalid choices are ignored. A URL never opens a local photo or fetches a remote background. Personal images require the local picker.

The footer identifies this edition as **Pen & Rhythm · October 3, 2026**. Newer application code checks the network first with an offline fallback; artwork remains cached. If a later update becomes ready while the app is open, Reload update preserves the browser draft and reloads the app. An older installed copy may need a second refresh after its new offline cache finishes installing.

## Reading history and journeys

Opening a card for reading automatically adds concise metadata such as `opened="2026-10-03:2,2026-10-04:1"`. This example means two openings on October 3 and one on October 4. The card badge counts distinct dates within the past **30 local calendar days**, including today. Opening the app, seeing a grid preview, or editing a new card does not count. Switching an editor back to Read card counts as an opening. Repeated openings on the same day remain in the metadata.

The desk counts distinct cards opened during that rolling 30-day window and how many cards in today’s rotation remain unopened. There is no required daily quota: “to revisit today” is an invitation to revisit people and needs.

Adventure atmospheres use ten card-days per level: each card can advance the journey once per local day. Opening the same card repeatedly does not add level credit. The compact `card-days` value in the desk metadata preserves earned progress even after a card is removed. New/imported decks can derive their starting credit from their date history. Stage names describe the atmosphere, not a person's faith, prayer quality, or spiritual standing. There are no streak penalties, leaderboards, timers, or notifications. Scripture snippets change as reading progress changes; there is no automatic animated rotation, and Show Scripture ribbons also controls these snippets.

| Atmosphere | Reminder presentation |
|---|---|
| Simple Bible | Plain rolling-month count and cards remaining today; no levels |
| Jungle Adventure, Galilee Spring | Visible trail/meadow milestones and Bring the next need |
| Summit & Sky | Restrained mountain journey |
| Deep Space | Cosmic journey with creation Scriptures |
| Woodland, Celestial | Forest/watch journeys and a small progress meter |
| Storm & Glory | Compact journey and prayer encouragement |
| Victorian, Stained Glass, Desert, Watercolor, Ohana | Counts beneath the deck; optional Journey progress expands below |

Today’s rotation includes **all daily cards**, a rotating **30% of weekly cards rounded up**, and **one as-needed card** when that category is present. Weekly cards are taken from a cyclic list, advancing by the number selected each day. With an unchanged deck, each weekly card is selected at least twice in every seven-day span. Small weekly pools may have a larger share because of rounding. Selections depend on local calendar dates and deck order, not reading history, so reading does not move the daily goal. The selection is recalculated if cards are added, removed, reordered, or given a new cadence. All cards remain available to read at any time.

Bring the next need prioritizes the unopened cards in today’s list. After completion, Bring another need chooses an unopened card outside the list before offering a revisit. Any card can still advance a level once per day. When the cards in today’s rotation have been opened, the app says: “Your prayers are full today. Your Father in heaven is always listening, so don’t hang up the conversation!” A short James 5:16 (CSB) excerpt remains underneath when Scripture is enabled. Opening a card is recorded; the app does not infer whether someone prayed.

In the editor, Prayer kind is followed immediately by the prayers. Rhythm stays below Scripture and story notes. Tint is small and below those fields. Theme, illustration, and local-photo controls live in a collapsed Appearance & local photo section. History and level credit travel in your Markdown and use the same local draft or linked-file autosave as your prayers. Export .md to keep the disk copy current in browsers without direct-file autosave.

## Saving and privacy

Your prayer file is processed on your device. The app has no prayer upload, analytics, AI, remote content retrieval, or server data endpoint. A restrictive page policy blocks network connections from the app. Markdown images, links, and arbitrary HTML are not interpreted; this prevents imported prayer text from triggering network requests or executing code. Generated decorative artwork is bundled locally.

Edits automatically save to a local browser recovery draft when browser storage is available. This draft is readable Markdown inside local storage, not a remote database. The app reports storage or write failures rather than claiming they saved.

**Direct file autosave:** browsers supporting the File System Access API can open or link a chosen `.md` file and write edits back to it. Only the explicitly chosen file is accessible. Its handle is remembered in local IndexedDB where supported. Browser permission may need to be granted again: use Reconnect file. A recovered draft is not automatically replaced by the disk file; a mismatch requires a choice before overwriting the file with that draft.

**Other browsers:** local draft autosave still works where storage is available. Export .md downloads a human-readable copy; it cannot silently overwrite the original file. Export regularly, especially before clearing browser data, changing browsers, or changing devices. Closing the app while a linked file write is pending, or while storage is unavailable, prompts where the browser supports unload warnings.

Exported Markdown is the portable long-term record. Clearing site data removes the draft and remembered file handle; it does not delete your own Markdown file. Remove this browser’s draft also leaves your file in place.

A supported local HTML browser on Android can run the self-contained copy. Some mobile file viewers—including common iPhone preview flows—do not run local HTML as an app. On iPhone, use the hosted app in Safari and optionally Add to Home Screen. After a successful first load, its service worker caches the app’s code and artwork for offline visits. This cache is separate from prayers; clearing browser data removes it. Support and storage persistence vary by browser. The downloadable copy is independent of the hosted service.

## Markdown format

```md
# My Prayer Cards
<!-- desk: theme="woodland" scripture="true" large="false" -->

## Anna
<!-- card: type="person" tint="#a96780" art="lantern" cadence="daily" theme="woodland" -->

- Grow in **wisdom** and love for Christ.
- Courage with the difficult relationship.

### Scripture
A Scripture fragment with its reference and translation.

### Story
2026-10-02 — An honest conversation. Still praying for reconciliation.
```

Each `## ` heading begins a card. `### Scripture`, `### Story`, and optional `### Prayer` identify the standard sections. Other level-three sections and card metadata are retained. Avoid level-two headings inside a prayer; they start a new card. This deliberately small renderer supports bullet lists, paragraphs, bold, italics, and underline, rather than implementing all Markdown features.

Card types: `person`, `family`, `church`, `heart`, `suffering`, `mission`, `story`, `thanks`.

Tints can be six-digit hex colors or `rose`, `blue`, `green`, `gold`, `purple`, `teal`, `orange`, `slate`.

Card theme defaults to the current desk theme. Use `theme="inherit"` or omit it to follow the desk.

| Theme key | Art variants |
|---|---|
| quiet | plain (no artwork), celtic-minimal, cross, celtic, flourish |
| victorian | fern, lily, ivy |
| space | nova, depth, orbit |
| jungle | canopy, river, forest |
| traditional | shepherd, bible, candle |
| celestial | watchman, messenger, light |
| storm | bible, compass, lightning |
| woodland | border, wonder |
| desert | lamp, arches, sunrise, shore |
| watercolor | border, meadow, stream, sea |
| summit | ridge |
| galilee | spring |
| ohana | sunset |

Earlier named artwork variants remain supported. `art="auto"` chooses a varied, deterministic illustration from the card title and kind. An explicit variant overrides it when that variant exists in the chosen theme. The artwork is presentation; it is never copied into the prayer Markdown.

## Source

The Source folder contains plain HTML, CSS, four small JavaScript files, a service worker, a manifest, and 45 optimized original artwork assets. There is no framework, build step, dependency installation, or server-side prayer code. Open Source/index.html locally, or serve that directory as static files. A service worker requires a supported secure hosted context; the standalone HTML works without it.

- `core.js`: Markdown parsing, serialization, safe rendering, and tint helpers.
- `data.js`: theme/type descriptions, artwork paths, and original starter templates.
- `progress.js`: local dates, opening history, rolling counts, and journey credit.
- `app.js`: local file handling, browser draft, card editor, and controls.

The service worker fetches and caches only a fixed list of application assets; it never processes prayer file contents. The downloaded HTML embeds the same code, styles, and artwork, and disables its service-worker path by running locally.

## Scripture and artwork

Starter Scripture fragments are labeled CSB excerpts. They comprise a small fraction of the original template and explanatory text; fewer than 30 verses are used, including the short journey excerpts. No complete Bible book or Bible database is bundled. User-written prayers and Scripture are retained as entered.

Scripture quotations marked CSB have been taken from the Christian Standard Bible®, Copyright © 2017 by Holman Bible Publishers. Used by permission. Christian Standard Bible® and CSB® are federally registered trademarks of Holman Bible Publishers.

Prayer-card background: https://seejesus.net/products/prayer-card-pack
Browser file-access reference: https://developer.mozilla.org/en-US/docs/Web/API/Window/showOpenFilePicker

All artwork scenes are original generated illustrations, not licensed characters or imitations of a specific film. The prompt set is included with the source.

Code by Daniel using ChatGPT — October 2, 2026

### Mixed background shuffle

In Mixed atmospheres, a small translucent shuffle button appears on each unpinned card and its enlarged reading view. It changes that card’s atmosphere and artwork without recording another read or changing the prayer. Choices are saved as `mixed-theme` and `mixed-art` in the card metadata. Custom photos, explicit card themes, and manually selected artwork stay pinned. Set art to Auto and card theme to Mixed or Use desk theme to enable shuffling again.

Settings includes an unchecked **Shuffle Mixed backgrounds whenever this deck opens** option. When enabled, eligible cards reshuffle once when the app starts or a Markdown deck opens—not while editing, opening individual cards, or refreshing the daily reminders. The preference is saved as `shuffle-on-open` in desk metadata and accepts `shuffle=on` or `shuffle=off` in appearance links.

Every card can use a local JPEG, PNG, or WebP smaller than 12 MB, regardless of atmosphere. Choose it in Appearance & local photo. The browser stores the image locally; Markdown stores its name/path label, not the image bytes. On another device, choose the original image again. Remote image URLs are inert.

### Life with the Father

The cards are reminders of people, needs, thanksgiving, and the Father’s unfolding work. They support an ongoing life with the Father through Jesus Christ, in the Spirit. Opening counts are device records, not measurements of prayer, communion, or faith. The language of the app invites you to bring the next need and to continue the conversation beyond the cards.

Simple Bible includes **Plain · no artwork**, which uses the near-white card surface without an image, and **Celtic · minimal**, with only two tiny geometric corner marks and no plant motifs. Auto uses these two quiet options; previous designs remain selectable. The full CSB copyright notice is visible in the footer and retained in Help, the starter Markdown, and this README. Built-in Scripture uses CSB only.

Mixed atmospheres is the default on first use and in the downloadable starter file. Each card receives its own atmosphere and artwork. Saved desk choices and explicit appearance links take precedence. Automatic reshuffle-on-open is still off by default.

### Prayer openings and file autosave

The blank prayer field varies between “Father, I ask…” and “Heavenly Dad, in Jesus I ask…” as a stable suggestion for each card. One starter template uses the latter opening. Existing prayer text is never rewritten. Copy appearance link is in Settings.

Opening a Markdown file in a supported secure browser offers write permission immediately, so edits autosave to that file after permission is granted. The status reports whether the file is linked or only the browser draft is saving. A new deck needs Link a file for autosave once. Export .md remains a secondary backup/copy action. Browsers without direct file access use local draft saving and explicit export; the app cannot silently update the imported disk file there.

### Revised starter prayers

The household, church, mission, and person templates now emphasize boldness, grace-filled speech, life and godliness in Messiah Jesus, and growth in the grace and knowledge of Christ. The household prayer names pride, lust, bitterness, using people, and the pull of approval, while asking the Spirit to shape desires and daily habits into genuine love. The church prayer asks elders to proclaim the Word boldly and teach the whole counsel of God faithfully and clearly, retaining humility, rest, intergenerational care, and service to Christ’s body.

These are original prayers informed by 2 Peter 1:3 and 3:18, Colossians 3:16 and 4:6, Ephesians 6:19–20, Acts 20:27, and Galatians 5:16–24. They are not additional Bible quotations or quotations from Dallas Willard. Existing saved prayer text is never migrated or rewritten.
