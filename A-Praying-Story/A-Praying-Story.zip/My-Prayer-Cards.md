# My Prayer Cards
<!-- desk: theme="mixed" scripture="true" large="false" shuffle-on-open="false" -->
<!-- Scripture quotations marked CSB have been taken from the Christian Standard Bible®, Copyright © 2017 by Holman Bible Publishers. Used by permission. Christian Standard Bible® and CSB® are federally registered trademarks of Holman Bible Publishers. -->

## Someone I love
<!-- card: type="person" tint="rose" art="auto" cadence="daily" -->

- Father, draw **[name]** nearer to Jesus and give them a growing love for your Word.
- Bring wisdom to the decision before them, boldness to do what is good, and friends who speak truth in love.
- Help me listen carefully and offer one practical act of care this week.

### Scripture
“put on compassion, kindness, humility, gentleness, and patience” — Colossians 3:12 (CSB excerpt)

### Story
[Date] — What are they carrying? What am I noticing as I pray?

## Our household
<!-- card: type="family" tint="gold" art="auto" cadence="daily" -->

- Lord, make our home a place of forgiveness, hospitality, and joyful faithfulness to Christ.
- Help us speak Christ’s word and be full of your grace. Let your will shape our words—with boldness, clarity, truth, and love.
- In Messiah Jesus you have given us everything we need for life and godliness. Teach us to draw on your grace and walk by your Spirit.
- Free us from the pull of our sinful desires and the world’s approval—from pride, lust, bitterness, and using people. Train our hearts and everyday habits to love as you love.

### Scripture
“Above all, put on love, which is the perfect bond of unity.” — Colossians 3:14 (CSB)

### Story
[Date] — Record a shared burden, a moment of grace, or a growing habit.

## Our church and its shepherds
<!-- card: type="church" tint="blue" art="auto" cadence="weekly" -->

- Jesus, build your church. Grow our elders in the grace and knowledge of you, our Lord and Savior; keep them humble, sustain them, and give them rest.
- Give them boldness to proclaim your Word as they ought, and wisdom to teach us the whole counsel of God faithfully and clearly.
- Strengthen love between generations and care for those easily overlooked. Teach us to receive your Word and obey it together.
- Help us use our gifts to build up your body and honor one another without chasing recognition.

### Scripture
“let us grow in every way into him who is the head—Christ” — Ephesians 4:15 (CSB excerpt)

### Story
[Date] — A person to encourage; a ministry to support; a need to remember.

## My own heart
<!-- card: type="heart" tint="purple" art="auto" cadence="daily" -->

- Heavenly Dad, in Jesus I ask you to show me where pride, fear, or self-reliance is keeping me from trusting you.
- Because Christ gave himself for me, teach me repentance and glad obedience.
- Name one specific habit to surrender, and one small faithful step to take today.

### Scripture
“He laid down his life for us.” — 1 John 3:16 (CSB excerpt)

### Story
[Date] — What do I need to confess? Where have I received mercy or learned dependence?

## Someone in suffering
<!-- card: type="suffering" tint="slate" art="auto" cadence="daily" -->

- God of mercy, sustain **[name]** in illness, grief, loneliness, or uncertainty.
- We ask for healing and relief, and trust your wisdom when the way is hard to understand.
- Give them hope in Christ and bring people who can carry the burden with them. Show me how to help.

### Scripture
“Carry one another’s burdens” — Galatians 6:2 (CSB excerpt)

### Story
[Date] — A change in the need; an offered meal; an honest conversation; a continuing question.

## Friends, neighbors, and the nations
<!-- card: type="mission" tint="teal" art="auto" cadence="weekly" -->

- Father, bring **[names / place]** to know Jesus, crucified and risen, and the grace of your gospel.
- Give missionaries and local believers boldness, wisdom, faithful teaching, and loving endurance.
- Open a door for me to listen, serve, and speak about Christ with boldness, deep grace, and clarity.

### Scripture
“salvation through our Lord Jesus Christ” — 1 Thessalonians 5:9 (CSB excerpt)

### Story
[Date] — An open conversation, a new relationship, or news from a ministry we support.

## A story still unfolding
<!-- card: type="story" tint="green" art="auto" cadence="weekly" -->

- Lord, I bring you this long-running situation: **[describe it simply]**.
- Help me ask honestly, persist patiently, and remain open to the way you are working.
- Form faithfulness through the waiting. Keep me from calling every event an answer when I do not yet understand.

### Scripture
“endurance produces proven character, and proven character produces hope” — Romans 5:4 (CSB excerpt)

### Story
[Date] — What has changed? What is unresolved? What grace can I thank God for along the way?

## Gifts I want to remember
<!-- card: type="thanks" tint="orange" art="auto" cadence="weekly" -->

- Father, thank you for salvation in Christ and the ordinary gifts I often overlook.
- Remember a person, a provision, a protection, or a changed heart; name the gift specifically.
- Teach me gratitude without ignoring the sorrow that may still be present.

### Scripture
“You have put more joy in my heart” — Psalm 4:7 (CSB excerpt)

### Story
[Date] — A gift to remember and a reason to praise the Lord.
